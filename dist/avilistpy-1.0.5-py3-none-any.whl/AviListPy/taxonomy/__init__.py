# -*- coding: utf-8 -*-
"""
Created on Sun Jun 22 12:54:54 2025

@author: Thomas Lee
Rice University
Department of Earth, Environmental, and Planetary Sciences
Email: tl165@rice.edu
"""

all = ['order','family','genus','species','subspecies']